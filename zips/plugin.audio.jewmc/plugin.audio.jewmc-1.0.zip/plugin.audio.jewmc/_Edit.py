import xbmcaddon
MainBase = 'https://raw.githubusercontent.com/jewbmx/xml/master/jewmx/MCmenu.txt'
addon = xbmcaddon.Addon('plugin.audio.jewmc')