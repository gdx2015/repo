import xbmcaddon
MainBase = 'https://raw.githubusercontent.com/jewbmx/repo/master/dox/menu.txt'
addon = xbmcaddon.Addon('plugin.audio.jewmc')