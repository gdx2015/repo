# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 03-17-2019 by JewBMX in Scrubs.
# Spare Tire, works fine.

import re,urllib,urlparse
from resources.lib.modules import client,cleantitle,source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['project-free-tv.ch', 'project-free-tv.ag']
        self.base_link = 'https://www9.project-free-tv.ag'
        self.search_tv = '%s-season-%d-episode-%d/'
        self.search_link = '%s-%d/'
        self.search_link_2 = '/episode/%s'


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            aliases.append({'country': 'us', 'title': tvshowtitle})
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year, 'aliases': aliases}
            url = urllib.urlencode(url)
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return
            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            clean_title = cleantitle.geturl(data['tvshowtitle'])
            url = urlparse.urljoin(self.base_link, self.search_link_2 % (self.search_tv % (clean_title, int(season), int(episode))))
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            r = client.request(url)
            links = re.findall('callvalue\((.+?)\)', r)
            for i in links:
                try:
                    url = re.findall('(http.+?)(?:\'|\")', i)[0]
                    quality = source_utils.check_url(url)
                    valid, host = source_utils.is_host_valid(url,hostDict)
                    sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'direct': False, 'debridonly': False})
                except:
                    pass
            return sources
        except:
            return sources


    def resolve(self, url):
        return url

