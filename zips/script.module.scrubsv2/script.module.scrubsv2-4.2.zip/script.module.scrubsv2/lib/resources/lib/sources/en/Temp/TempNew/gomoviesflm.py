# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 02-14-2019 by JewBMX in Scrubs.
# Created by Tempest

import re
from resources.lib.modules import client,cleantitle,source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['ww3.gomovies.film']
        self.base_link = 'https://ww3.gomovies.film'
        self.search_link = '/search-query/%s+%s/'
# https://ww3.123movieshub.film/


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            title = cleantitle.geturl(title).replace('-', '+')
            i = self.base_link + self.search_link % (title, year)
            i = client.request(i)
            i = client.parseDOM(i, "div", attrs={"class": "movies-list movies-list-full"})
            for r in i:
                r = re.compile('<a href="(https://ww3.gomovies.film/movie/.+?)" .+? title=".+?"').findall(r)
                for url in r:
                    url = url + 'watching.html/'
                    return url
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            hostDict = hostprDict + hostDict
            r = client.request(url)
            u = client.parseDOM(r, "div", attrs={"id": "list-eps"})
            for t in u:
                t = client.parseDOM(r, "div", attrs={"class": "les-content"})
                try:
                    for i in t:
                        i = re.compile('<a title=".+?" data-openload="(.+?)"').findall(r)
                        for url in i:
                            url = url
                            quality = source_utils.check_url(url)
                            valid, host = source_utils.is_host_valid(url, hostDict)
                            if valid:
                                sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'direct': False, 'debridonly': False})
                    return sources
                except:
                    return
        except:
            return


    def resolve(self, url):
        return url

