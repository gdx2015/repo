# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 02-18-2019 by JewBMX in Scrubs.

import re
from resources.lib.modules import client,cleantitle,source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['bfmovies.net']
        self.base_link = 'https://www2.bfmovies.net'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            title = cleantitle.geturl(title)
            url = self.base_link + '/movies/%s-%s/' % (title,year)
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            r = client.request(url)
            try:
                qual = re.compile('class="quality">Quality: <span>(.+?)</span>').findall(r)
                for q in qual:
                    if '2160' in q: quality = '4K'
                    elif '4k' in q: quality = '4K'
                    elif '1080' in q: quality = '1080p'
                    elif '720' in q: quality = 'HD'
                    elif '480' in q: quality = 'SD'
                    elif 'HD' in q: quality = 'HD'
                    elif 'SD' in q: quality = 'SD'
                    else: quality = source_utils.check_url(url)
                match = re.compile('<iframe src="(.+?)".+?</iframe>').findall(r)
                for url in match:
                    info = q
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if valid:
                        sources.append({'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': url, 'direct': False, 'debridonly': False}) 
            except:
                return
        except Exception:
            return
        return sources


    def resolve(self, url):
        return url

