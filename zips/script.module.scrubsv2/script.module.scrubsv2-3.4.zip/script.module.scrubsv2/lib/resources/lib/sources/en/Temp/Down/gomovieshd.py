# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 01-14-2019 by JewBMX in Scrubs.

import re
from resources.lib.modules import cleantitle,source_utils,directstream,cfscrape


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['gomovieshd.cc']
        self.base_link = 'https://gomovieshd.cc'
        self.search_link = '/%s'
        self.scraper = cfscrape.create_scraper()
        # Sites Down 01-21


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            title = cleantitle.geturl(title)
            url = self.base_link + self.search_link % (title)
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            r = self.scraper.get(url).content
            qual = re.compile('class="quality">(.+?)<').findall(r)
            for i in qual:
                if 'HD' in i:
                    quality = '720p'
                elif 'cam' in i:
                    quality = 'cam'
                else:
                    quality = 'SD'
            match = re.compile('<iframe src="(.+?)"').findall(r)
            for url in match:
                valid, host = source_utils.is_host_valid(url, hostDict)
                sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'direct': False, 'debridonly': False})
            return sources
        except Exception:
            return


    def resolve(self, url):
        return directstream.googlepass(url)

