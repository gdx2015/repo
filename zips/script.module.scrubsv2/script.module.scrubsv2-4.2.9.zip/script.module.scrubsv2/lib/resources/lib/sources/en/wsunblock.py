# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 03-17-2019 by JewBMX in Scrubs.

import re,urllib,urlparse,base64
from resources.lib.modules import client,cleantitle,source_utils,proxy,cfscrape


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['watchseries.unblocker.cc']
        self.base_link = 'https://watchseries.unblocker.cc'
        self.search_link = 'https://watchseries.unblocker.cc/episode/%s_s%s_e%s.html'
        self.scraper = cfscrape.create_scraper()


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = cleantitle.geturl(tvshowtitle)
            url = url.replace('-', '_')
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url: return
            url = self.search_link % (url,season,episode)
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            openload_limit = 1
            clipwatch_limit = 1
            speedvid_limit = 1
            streamplay_limit = 1
            mango_limit = 1
            vidlox_limit = 1
            vidoza_limit = 1
            vidtodo_limit = 1
            flashx_limit = 1
            vidcloud_limit = 1
            gorillavid_limit = 1
            vshare_limit = 1
            powvid_limit = 1
            vev_limit = 1
            movpod_limit = 1
            daclips_limit = 1
            r = self.scraper.get(url).content
            match = re.compile('cale\.html\?r=(.+?)" class="watchlink" title="(.+?)"').findall(r)
            for url, host in match:
                if 'openload' in host:
                    if openload_limit < 1:
                        continue
                    else:
                        openload_limit -= 1
                if 'clipwatch' in host:
                    if clipwatch_limit < 1:
                        continue
                    else:
                        clipwatch_limit -= 1
                if 'speedvid' in host:
                    if speedvid_limit < 1:
                        continue
                    else:
                        speedvid_limit -= 1
                if 'streamplay' in host:
                    if streamplay_limit < 1:
                        continue
                    else:
                        streamplay_limit -= 1
                if 'mango' in host:
                    if mango_limit < 1:
                        continue
                    else:
                        mango_limit -= 1
                if 'vidlox' in host:
                    if vidlox_limit < 1:
                        continue
                    else:
                        vidlox_limit -= 1
                if 'vidoza' in host:
                    if vidoza_limit < 1:
                        continue
                    else:
                        vidoza_limit -= 1
                if 'vidtodo' in host:
                    if vidtodo_limit < 1:
                        continue
                    else:
                        vidtodo_limit -= 1
                if 'flashx' in host:
                    if flashx_limit < 1:
                        continue
                    else:
                        flashx_limit -= 1
                if 'vidcloud' in host:
                    if vidcloud_limit < 1:
                        continue
                    else:
                        vidcloud_limit -= 1
                if 'gorillavid' in host:
                    if gorillavid_limit < 1:
                        continue
                    else:
                        gorillavid_limit -= 1
                if 'vshare' in host:
                    if vshare_limit < 1:
                        continue
                    else:
                        vshare_limit -= 1
                if 'powvid' in host:
                    if powvid_limit < 1:
                        continue
                    else:
                        powvid_limit -= 1
                if 'vev' in host:
                    if vev_limit < 1:
                        continue
                    else:
                        vev_limit -= 1
                if 'movpod' in host:
                    if movpod_limit < 1:
                        continue
                    else:
                        movpod_limit -= 1
                if 'daclips' in host:
                    if daclips_limit < 1:
                        continue
                    else:
                        daclips_limit -= 1
                url  = base64.b64decode(url)
                info = source_utils.check_url(url)
                quality = source_utils.check_url(url)
                valid, host = source_utils.is_host_valid(host, hostDict)
                if valid:
                    sources.append({'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': url, 'direct': False, 'debridonly': False}) 
        except Exception:
            return
        return sources


    def resolve(self, url):
        return url

