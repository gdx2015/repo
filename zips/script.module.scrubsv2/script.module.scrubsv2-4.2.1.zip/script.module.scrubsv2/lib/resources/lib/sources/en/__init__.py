# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 01-14-2019 by JewBMX in Scrubs.

import os.path

files = os.listdir(os.path.dirname(__file__))
__all__ = [filename[:-3] for filename in files if not filename.startswith('__') and filename.endswith('.py')]


###Dev Shit.
# if test.status() is False: raise Exception()

# from resources.lib.modules import cfscrape
# self.scraper = cfscrape.create_scraper()
# r = self.scraper.get(url).content

# import xbmcgui
# xbmcgui.Dialog ().textviewer ("data",str (name))

# from resources.lib.modules import log_utils
# log_utils.log('---Scraper Testing - Sources - url: ' + str(url))

