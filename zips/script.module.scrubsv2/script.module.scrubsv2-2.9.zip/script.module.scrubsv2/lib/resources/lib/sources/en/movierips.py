# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 12-31-2018 by JewBMX in Scrubs.
#Created by Tempest

import re,requests
from resources.lib.modules import client,cleantitle


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['movierips.ga']
        self.base_link = 'https://movierips.ga'
        self.search_link = '/%s-%s'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            title = cleantitle.geturl(title)
            url = self.base_link + self.search_link % (title, year)
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            r = requests.get(url).content
            u = client.parseDOM(r, "div", attrs={"class": "entry-inner"})
            for t in u:
                r = re.findall('iframe src="(.+?)"', t)
                for url in r:
                    sources.append({'source': 'openload', 'quality': '1080p', 'language': 'en', 'url': url, 'direct': False, 'debridonly': False})
                return sources
        except:
            return


    def resolve(self, url):
        return url

