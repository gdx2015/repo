# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 02-01-2019 by JewBMX in Scrubs.

import re,urllib,urlparse 
from resources.lib.modules import cleantitle,client,proxy,cfscrape


class source:
	def __init__(self):
		self.priority = 1
		self.language = ['en']
		self.domains = ['openloadmovie.org','openloadmovie.ws']
		self.base_link = 'https://openloadmovie.org'
		self.scraper = cfscrape.create_scraper()


	def movie(self, imdb, title, localtitle, aliases, year):
		try:
			title = cleantitle.geturl(title)
			url = self.base_link + '/movies/%s-%s' % (title,year)
			return url
		except:
			return


	def sources(self, url, hostDict, hostprDict):
		try:
			sources = []
			r = self.scraper.get(url).content
			match = re.compile('<iframe class="metaframe rptss" src="(.+?)"').findall(r)
			for url in match: 
				sources.append({'source': 'openload.co','quality': 'HD','language': 'en','url': url,'direct': False,'debridonly': False})
		except Exception:
			return
		return sources


	def resolve(self, url):
		return url

